<h1>Serverless Challenge</h1>
<h3>Link para <a href="https://foggy-drug-9b5.notion.site/Documenta-o-Serverless-Challenge-706933dc6808486ca1856ea28e235bfa">Documentação Externa</a></h3>
Desafio realizado com base no seguinte repositório: https://github.com/dornellas13/serverless-challenge
